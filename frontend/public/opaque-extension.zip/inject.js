(function() {
	//#region src/lib/opaque-adapter.ts
	const ICON = "data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%228%22 fill=%22%23070608%22/%3E%3Cpath d=%22M16 7l9 9-9 9-9-9z%22 fill=%22none%22 stroke=%22%23ff7a18%22 stroke-width=%222%22/%3E%3C/svg%3E";
	var OpaqueAdapter = class {
		id = "opaque";
		name = "Opaque";
		icon = ICON;
		url;
		capabilities = {
			sign: true,
			signAndSubmit: true,
			signMessage: true
		};
		#walletUrl;
		#origin;
		#timeoutMs;
		#popup = null;
		#ready;
		#account = null;
		#next = 0;
		#listeners = /* @__PURE__ */ new Map();
		constructor(options = {}) {
			this.#walletUrl = options.walletUrl ?? "https://www.opaque.credit/testnet/xrpl-connect";
			this.#origin = new URL(this.#walletUrl).origin;
			this.#timeoutMs = options.timeoutMs ?? 3e5;
			this.url = this.#origin;
		}
		async isAvailable() {
			return typeof window !== "undefined" && typeof window.open === "function";
		}
		/** A stored account reconnects without a popup. */
		serializeReconnectOptions() {
			return this.#account === null ? void 0 : { account: this.#account };
		}
		async connect(options) {
			if (options?.account?.address !== void 0) this.#account = options.account;
			else this.#account = await this.#request("connect", { network: options?.network?.id ?? null });
			this.#emit("connect", this.#account);
			return this.#account;
		}
		async disconnect() {
			this.#account = null;
			this.#popup?.close();
			this.#popup = null;
			this.#emit("disconnect", null);
		}
		async getAccount() {
			return this.#account;
		}
		async getNetwork() {
			if (this.#account === null) throw new Error("Opaque is not connected");
			return this.#account.network;
		}
		sign(transaction) {
			return this.#request("sign", { transaction });
		}
		signAndSubmit(transaction) {
			return this.#request("signAndSubmit", { transaction });
		}
		signMessage(message) {
			const text = typeof message === "string" ? { message } : { hex: Array.from(message, (b) => b.toString(16).padStart(2, "0")).join("") };
			return this.#request("signMessage", text);
		}
		on(event, callback) {
			const set = this.#listeners.get(event) ?? /* @__PURE__ */ new Set();
			set.add(callback);
			this.#listeners.set(event, set);
		}
		off(event, callback) {
			this.#listeners.get(event)?.delete(callback);
		}
		#emit(event, data) {
			for (const cb of this.#listeners.get(event) ?? []) cb(data);
		}
		/** Opens the popup once, and reuses it while it stays open. */
		#open() {
			if (this.#popup !== null && !this.#popup.closed && this.#ready !== void 0) return this.#ready;
			const popup = window.open(this.#walletUrl, "opaque-wallet", "popup,width=440,height=700");
			if (popup === null) return Promise.reject(/* @__PURE__ */ new Error("the browser blocked the Opaque popup; allow popups for this site"));
			this.#popup = popup;
			this.#ready = new Promise((resolve, reject) => {
				const timer = setTimeout(() => {
					window.removeEventListener("message", onReady);
					reject(/* @__PURE__ */ new Error("the Opaque wallet did not open"));
				}, 6e4);
				const onReady = (event) => {
					if (event.source !== popup || event.origin !== this.#origin || event.data?.type !== "opaque:ready") return;
					clearTimeout(timer);
					window.removeEventListener("message", onReady);
					resolve();
				};
				window.addEventListener("message", onReady);
			});
			return this.#ready;
		}
		async #request(method, params) {
			await this.#open();
			const popup = this.#popup;
			const id = `${Date.now()}-${this.#next++}`;
			return new Promise((resolve, reject) => {
				const done = () => {
					clearTimeout(timer);
					clearInterval(closed);
					window.removeEventListener("message", onMessage);
				};
				const timer = setTimeout(() => {
					done();
					reject(/* @__PURE__ */ new Error(`Opaque: ${method} timed out`));
				}, this.#timeoutMs);
				const closed = setInterval(() => {
					if (popup.closed) {
						done();
						reject(/* @__PURE__ */ new Error("the Opaque window was closed"));
					}
				}, 500);
				const onMessage = (event) => {
					const data = event.data;
					if (event.source !== popup || event.origin !== this.#origin || data?.type !== "opaque:response" || data.id !== id) return;
					done();
					if (data.error !== void 0) reject(new Error(data.error));
					else resolve(data.result);
				};
				window.addEventListener("message", onMessage);
				popup.postMessage({
					type: "opaque:request",
					id,
					method,
					params
				}, this.#origin);
			});
		}
	};
	//#endregion
	//#region src/lib/opaque-eth-provider.ts
	const SEPOLIA = "0xaa36a7";
	const RPC = "https://ethereum-sepolia-rpc.publicnode.com";
	const OPAQUE_ICON = "data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%228%22 fill=%22%23070608%22/%3E%3Cg fill=%22%23ff7a18%22%3E%3Ccircle cx=%2216%22 cy=%225.6%22 r=%222.6%22/%3E%3Ccircle cx=%2223.4%22 cy=%228.6%22 r=%222.6%22/%3E%3Ccircle cx=%2226.4%22 cy=%2216%22 r=%222.6%22/%3E%3Ccircle cx=%2223.4%22 cy=%2223.4%22 r=%222.6%22/%3E%3Ccircle cx=%2216%22 cy=%2226.4%22 r=%222.6%22/%3E%3Ccircle cx=%228.6%22 cy=%2223.4%22 r=%222.6%22/%3E%3Ccircle cx=%225.6%22 cy=%2216%22 r=%222.6%22/%3E%3Ccircle cx=%228.6%22 cy=%228.6%22 r=%222.6%22/%3E%3C/g%3E%3C/svg%3E";
	/** What only Opaque's window may answer: everything else is a read any RPC answers. */
	const WALLET_METHODS = /* @__PURE__ */ new Set(["eth_requestAccounts", "eth_sendTransaction"]);
	const UNSUPPORTED = /* @__PURE__ */ new Set([
		"personal_sign",
		"eth_sign",
		"eth_signTypedData",
		"eth_signTypedData_v3",
		"eth_signTypedData_v4",
		"eth_signTransaction"
	]);
	var ProviderRpcError = class extends Error {
		code;
		constructor(code, message) {
			super(message);
			this.code = code;
		}
	};
	var OpaqueEthProvider = class {
		isOpaque = true;
		#url;
		#popup = null;
		#ready;
		#next = 0;
		#saved;
		#listeners = /* @__PURE__ */ new Map();
		/** A function where the URL is known only later: the extension's bridge sets it beside this script. */
		constructor(options = {}) {
			const url = options.walletUrl ?? "https://www.opaque.credit/sepolia/eth-connect";
			this.#url = typeof url === "string" ? () => url : url;
		}
		get #origin() {
			return new URL(this.#url()).origin;
		}
		#key() {
			return `opaque:eth-accounts:${this.#origin}`;
		}
		get #accounts() {
			this.#saved ??= (() => {
				try {
					return JSON.parse(localStorage.getItem(this.#key()) ?? "[]");
				} catch {
					return [];
				}
			})();
			return this.#saved;
		}
		set #accounts(list) {
			this.#saved = list;
			try {
				if (list.length === 0) localStorage.removeItem(this.#key());
				else localStorage.setItem(this.#key(), JSON.stringify(list));
			} catch {}
		}
		async request({ method, params = [] }) {
			const list = Array.isArray(params) ? params : [params];
			switch (method) {
				case "eth_chainId": return SEPOLIA;
				case "net_version": return "11155111";
				case "eth_accounts": return [...this.#accounts];
				case "wallet_switchEthereumChain":
					if (String(list[0]?.chainId ?? "").toLowerCase() === SEPOLIA) return null;
					throw new ProviderRpcError(4902, "Opaque is on Sepolia: its post-quantum accounts are not on that chain yet");
				case "wallet_requestPermissions":
					await this.request({ method: "eth_requestAccounts" });
					return [{ parentCapability: "eth_accounts" }];
				case "wallet_revokePermissions":
					this.#accounts = [];
					this.#emit("accountsChanged", []);
					return null;
			}
			if (UNSUPPORTED.has(method)) throw new ProviderRpcError(4200, `Opaque signs transactions with a post-quantum key; it does not make ${method} signatures yet`);
			if (WALLET_METHODS.has(method)) {
				if (method === "eth_requestAccounts" && this.#accounts.length > 0) return [...this.#accounts];
				if (method === "eth_sendTransaction" && this.#accounts.length === 0) throw new ProviderRpcError(4100, "connect Opaque first (eth_requestAccounts)");
				const result = await this.#ask(method, list);
				if (method === "eth_requestAccounts") {
					this.#accounts = result;
					this.#emit("connect", { chainId: SEPOLIA });
					this.#emit("accountsChanged", this.#accounts);
				}
				return result;
			}
			const body = await (await fetch(RPC, {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({
					jsonrpc: "2.0",
					id: 1,
					method,
					params: list
				})
			})).json();
			if (body.error !== void 0) throw new ProviderRpcError(body.error.code, body.error.message);
			return body.result;
		}
		on(event, callback) {
			const set = this.#listeners.get(event) ?? /* @__PURE__ */ new Set();
			set.add(callback);
			this.#listeners.set(event, set);
			return this;
		}
		removeListener(event, callback) {
			this.#listeners.get(event)?.delete(callback);
			return this;
		}
		#emit(event, data) {
			for (const cb of this.#listeners.get(event) ?? []) cb(data);
		}
		/** Opaque's window, opened once and reused while it stays open. */
		#open() {
			if (this.#popup !== null && !this.#popup.closed && this.#ready !== void 0) return this.#ready;
			const popup = window.open(this.#url(), "opaque-eth-wallet", "popup,width=440,height=720");
			if (popup === null) return Promise.reject(new ProviderRpcError(4001, "the browser blocked the Opaque window; allow popups for this site"));
			this.#popup = popup;
			this.#ready = new Promise((resolve, reject) => {
				const timer = setTimeout(() => {
					removeEventListener("message", onReady);
					reject(new ProviderRpcError(4001, "the Opaque window did not open"));
				}, 12e4);
				const onReady = (event) => {
					if (event.source !== popup || event.origin !== this.#origin || event.data?.type !== "opaque:ready") return;
					clearTimeout(timer);
					removeEventListener("message", onReady);
					resolve();
				};
				addEventListener("message", onReady);
			});
			return this.#ready;
		}
		async #ask(method, params) {
			await this.#open();
			const popup = this.#popup;
			const id = `${Date.now()}-${this.#next++}`;
			return new Promise((resolve, reject) => {
				const done = () => {
					clearInterval(closed);
					removeEventListener("message", onMessage);
				};
				const closed = setInterval(() => {
					if (popup.closed) {
						done();
						reject(new ProviderRpcError(4001, "the Opaque window was closed"));
					}
				}, 500);
				const onMessage = (event) => {
					const data = event.data;
					if (event.source !== popup || event.origin !== this.#origin || data?.type !== "opaque:response" || data.id !== id) return;
					done();
					if (data.error !== void 0) reject(new ProviderRpcError(data.code ?? 4001, data.error));
					else resolve(data.result);
				};
				addEventListener("message", onMessage);
				popup.postMessage({
					type: "opaque:request",
					id,
					method,
					params
				}, this.#origin);
			});
		}
	};
	/** EIP-6963: tell the page Opaque is here, now and whenever it asks again. */
	function announceOpaque(provider) {
		const detail = Object.freeze({
			info: Object.freeze({
				uuid: crypto.randomUUID(),
				name: "Opaque",
				icon: OPAQUE_ICON,
				rdns: "credit.opaque"
			}),
			provider
		});
		const announce = () => dispatchEvent(new CustomEvent("eip6963:announceProvider", { detail }));
		addEventListener("eip6963:requestProvider", announce);
		announce();
	}
	//#endregion
	//#region ../extension/inject.ts
	const WSS = "wss://s.altnet.rippletest.net:51233";
	const HOSTED = "https://www.opaque.credit/testnet/xrpl-connect";
	const walletUrl = () => {
		const named = document.documentElement.dataset["opaqueWallet"] ?? "";
		return /^chrome-extension:\/\/[a-p]{32}\/testnet\/xrpl-connect\.html$/.test(named) ? named : HOSTED;
	};
	let opened;
	/** Made on first use: by then bridge.js has run, whichever script the browser started first. */
	const adapter = () => opened ??= new OpaqueAdapter({ walletUrl: walletUrl() });
	const SAVED = () => `opaque-extension:account:${new URL(walletUrl()).origin}`;
	let account;
	const saved = () => {
		try {
			return JSON.parse(localStorage.getItem(SAVED()) ?? "null");
		} catch {
			return null;
		}
	};
	function connected() {
		account ??= (async () => {
			const known = saved();
			const a = known !== null ? await adapter().connect({ account: known }) : await adapter().connect({ network: { id: "testnet" } });
			try {
				localStorage.setItem(SAVED(), JSON.stringify(a));
			} catch {}
			return a;
		})().catch((e) => {
			account = void 0;
			throw e;
		});
		return account;
	}
	const withAccount = async (tx) => ({
		...tx,
		Account: tx?.["Account"] ?? (await connected()).address
	});
	const rejected = (e) => /rejected in Opaque|window was closed/.test(String(e?.message));
	const hexBytes = (hex) => Uint8Array.from(hex.match(/../g) ?? [], (b) => parseInt(b, 16));
	const PAYMENT_FIELDS = {
		amount: "Amount",
		destination: "Destination",
		destinationTag: "DestinationTag",
		invoiceID: "InvoiceID",
		paths: "Paths",
		sendMax: "SendMax",
		deliverMin: "DeliverMin",
		sourceTag: "SourceTag",
		fee: "Fee"
	};
	/** sendPayment's fields as a Payment. Anything it can't carry is refused, never dropped. */
	function paymentOf(p) {
		const tx = { TransactionType: "Payment" };
		for (const [key, value] of Object.entries(p)) {
			if (value === void 0) continue;
			if (key in PAYMENT_FIELDS) tx[PAYMENT_FIELDS[key]] = value;
			else if (key === "flags" && typeof value === "number") tx["Flags"] = value;
			else if (key === "memos" && Array.isArray(value)) tx["Memos"] = value.map(({ memo }) => ({ Memo: Object.fromEntries(Object.entries({
				MemoType: memo.memoType,
				MemoData: memo.memoData,
				MemoFormat: memo.memoFormat
			}).filter(([, v]) => v !== void 0)) }));
			else throw new Error(`Opaque does not take ${key} in sendPayment; submitTransaction takes any Payment`);
		}
		return tx;
	}
	async function gem(type, p) {
		switch (type) {
			case "REQUEST_GET_NETWORK/V3": return {
				chain: "XRPL",
				network: "Testnet",
				websocket: WSS
			};
			case "REQUEST_GET_ADDRESS/V3": return { address: (await connected()).address };
			case "REQUEST_GET_PUBLIC_KEY/V3": {
				const a = await connected();
				return {
					address: a.address,
					publicKey: a.publicKey ?? ""
				};
			}
			case "REQUEST_SIGN_TRANSACTION/V3": return { signature: (await adapter().sign(await withAccount(p["transaction"]))).tx_blob };
			case "REQUEST_SUBMIT_TRANSACTION/V3": return { hash: (await adapter().signAndSubmit(await withAccount(p["transaction"]))).hash };
			case "REQUEST_SEND_PAYMENT/V3": return { hash: (await adapter().signAndSubmit(await withAccount(paymentOf(p)))).hash };
			case "REQUEST_SIGN_MESSAGE/V3": {
				const message = String(p["message"]);
				return { signedMessage: (await adapter().signMessage(p["isHex"] === true ? hexBytes(message) : message)).signature };
			}
			default: throw new Error(`Opaque does not answer ${type}; submitTransaction takes any transaction`);
		}
	}
	Object.assign(window, { gemWallet: true });
	window.addEventListener("message", (event) => {
		const d = event.data;
		if (event.source !== window || d?.source !== "GEM_WALLET_MSG_REQUEST" || typeof d.type !== "string") return;
		const reply = (body) => window.postMessage({
			source: "GEM_WALLET_MSG_RESPONSE",
			messagedId: d.messageId,
			...body
		}, location.origin);
		if (d.type === "REQUEST_IS_INSTALLED/V3") {
			reply({ isInstalled: true });
			return;
		}
		if (d.type === "REQUEST_CONNECTION") {
			reply({ isConnected: true });
			return;
		}
		gem(d.type, d.payload ?? {}).then((result) => reply({ result }), (e) => reply(rejected(e) ? {} : { error: {
			name: "Error",
			message: e.message,
			stack: ""
		} }));
	});
	const NETWORK = {
		protocol: "xrpl",
		type: "testnet",
		label: "XRPL",
		wss: WSS,
		rpc: "https://s.altnet.rippletest.net:51234"
	};
	async function crossmark(command, data) {
		const tx = data["tx"];
		switch (command) {
			case "network": return { network: NETWORK };
			case "address": return { address: (account === void 0 ? saved() : await account.catch(() => null))?.address };
			case "sign":
				if (tx?.["TransactionType"] === "SignIn") {
					const a = await connected();
					return {
						address: a.address,
						publicKey: a.publicKey ?? "",
						network: NETWORK
					};
				}
				return { txBlob: (await adapter().sign(await withAccount(tx))).tx_blob };
			case "sign-and-submit": return { resp: { result: { hash: (await adapter().signAndSubmit(await withAccount(tx))).hash } } };
			default: throw new Error(`Opaque does not answer Crossmark's ${command}`);
		}
	}
	Object.assign(window, { xrpl: Object.assign(window.xrpl ?? {}, { isCrossmark: true }) });
	window.addEventListener("message", (event) => {
		const d = event.data;
		if (event.source !== window || d?.type !== "request" || typeof d.id !== "string" || typeof d.command !== "string") return;
		const reply = (data) => window.postMessage({
			type: "response",
			request: d,
			response: {
				type: "response",
				id: d.id,
				data
			}
		}, location.origin);
		crossmark(d.command, d.data ?? {}).then(reply, (e) => reply({
			meta: rejected(e) ? { isRejected: true } : { isError: true },
			error: e.message
		}));
	});
	const ETH_HOSTED = "https://www.opaque.credit/sepolia/eth-connect";
	const ethWalletUrl = () => {
		const named = document.documentElement.dataset["opaqueEthWallet"] ?? "";
		return /^chrome-extension:\/\/[a-p]{32}\/sepolia\/eth-connect\.html$/.test(named) ? named : ETH_HOSTED;
	};
	announceOpaque(new OpaqueEthProvider({ walletUrl: ethWalletUrl }));
	//#endregion
})();
