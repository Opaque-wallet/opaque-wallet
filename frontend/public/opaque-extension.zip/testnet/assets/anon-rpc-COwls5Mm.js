const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./dist-CWBTRk4s.js","./dist-ClDFUWR_.js"])))=>i.map(i=>d[i]);
import{C as e,_ as t,b as n,d as r,m as i,t as a,u as o,v as s,w as c,x as l,y as u}from"./storage-name-D87f12i1.js";import{t as d}from"./preload-helper-HclGiUj8.js";import{n as f,t as p}from"./dist-ClDFUWR_.js";var ee=class{#e=[];#t=[];take(e){let t=this.#e.shift();return t===void 0?new Promise((t,n)=>{let r={resolve:n=>{e?.removeEventListener(`abort`,i),t(n)},reject:t=>{e?.removeEventListener(`abort`,i),n(t)}},i=()=>{let t=this.#t.indexOf(r);t>=0&&this.#t.splice(t,1),n(e?.reason??new DOMException(`aborted`,`AbortError`))};if(e?.aborted)return i();e?.addEventListener(`abort`,i,{once:!0}),this.#t.push(r)}):Promise.resolve(t)}push(e){let t=this.#t.shift();t?t.resolve(e):this.#e.push(e)}pushFront(e){let t=this.#t.shift();t?t.resolve(e):this.#e.unshift(e)}remove(e){let t=this.#e.indexOf(e);return t<0?!1:(this.#e.splice(t,1),!0)}rejectAll(e){let t=this.#e.splice(0);for(let t of this.#t.splice(0))t.reject(e);return t}},te=class{#e=[];#t=[];#n;#r;constructor(e){this.#r=e}dropped=0;take(e){let t=this.#e.shift();return t===void 0?this.#n?Promise.reject(this.#n.err):new Promise((t,n)=>{let r={resolve:n=>{e?.removeEventListener(`abort`,i),t(n)},reject:t=>{e?.removeEventListener(`abort`,i),n(t)}},i=()=>{let t=this.#t.indexOf(r);t>=0&&this.#t.splice(t,1),n(e?.reason??new DOMException(`aborted`,`AbortError`))};if(e?.aborted)return i();e?.addEventListener(`abort`,i,{once:!0}),this.#t.push(r)}):Promise.resolve(t)}push(e){if(this.#n)return;let t=this.#t.shift();if(t)return t.resolve(e);for(this.#e.push(e);this.#e.length>this.#r;)this.#e.shift(),this.dropped++}close(e){if(!this.#n){this.#n={err:e};for(let t of this.#t.splice(0))t.reject(e)}}get size(){return this.#e.length}},m=BigInt(2**32-1),h=BigInt(32);function g(e,t=!1){return t?{h:Number(e&m),l:Number(e>>h&m)}:{h:Number(e>>h&m)|0,l:Number(e&m)|0}}function _(e,t=!1){let n=new Uint32Array(e.length),r=new Uint32Array(e.length);for(let i=0;i<e.length;i++){let{h:a,l:o}=g(e[i],t);[n[i],r[i]]=[a,o]}return[n,r]}var ne=(e,t,n)=>e<<n|t>>>32-n,re=(e,t,n)=>t<<n|e>>>32-n,ie=(e,t,n)=>t<<n-32|e>>>64-n,ae=(e,t,n)=>e<<n-32|t>>>64-n,v=[],y=[],b=[],x=BigInt(0),S=BigInt(1),C=BigInt(2),oe=BigInt(7),se=BigInt(256),ce=BigInt(113);for(let e=0,t=S,n=1,r=0;e<24;e++){[n,r]=[r,(2*n+3*r)%5],v.push(2*(5*r+n)),y.push((e+1)*(e+2)/2%64);let i=x;for(let e=0;e<7;e++)t=(t<<S^(t>>oe)*ce)%se,t&C&&(i^=S<<(S<<BigInt(e))-S);b.push(i)}var[le,ue]=_(b,!0),w=(e,t,n)=>n>32?ie(e,t,n):ne(e,t,n),T=(e,t,n)=>n>32?ae(e,t,n):re(e,t,n);function de(e,t=24){let n=new Uint32Array(10);for(let r=24-t;r<24;r++){for(let t=0;t<10;t++)n[t]=e[t]^e[t+10]^e[t+20]^e[t+30]^e[t+40];for(let t=0;t<10;t+=2){let r=(t+8)%10,i=(t+2)%10,a=n[i],o=n[i+1],s=w(a,o,1)^n[r],c=T(a,o,1)^n[r+1];for(let n=0;n<50;n+=10)e[t+n]^=s,e[t+n+1]^=c}let t=e[2],i=e[3];for(let n=0;n<24;n++){let r=y[n],a=w(t,i,r),o=T(t,i,r),s=v[n];t=e[s],i=e[s+1],e[s]=a,e[s+1]=o}for(let t=0;t<50;t+=10){for(let r=0;r<10;r++)n[r]=e[t+r];for(let r=0;r<10;r++)e[t+r]^=~n[(r+2)%10]&n[(r+4)%10]}e[0]^=le[r],e[1]^=ue[r]}n.fill(0)}var fe=class a extends o{constructor(t,n,r,i=!1,a=24){if(super(),this.blockLen=t,this.suffix=n,this.outputLen=r,this.enableXOF=i,this.rounds=a,this.pos=0,this.posOut=0,this.finished=!1,this.destroyed=!1,e(r),0>=this.blockLen||this.blockLen>=200)throw Error(`Sha3 supports only keccak-f1600 function`);this.state=new Uint8Array(200),this.state32=s(this.state)}keccak(){i||r(this.state32),de(this.state32,this.rounds),i||r(this.state32),this.posOut=0,this.pos=0}update(e){l(this);let{blockLen:n,state:r}=this;e=t(e);let i=e.length;for(let t=0;t<i;){let a=Math.min(n-this.pos,i-t);for(let n=0;n<a;n++)r[this.pos++]^=e[t++];this.pos===n&&this.keccak()}return this}finish(){if(this.finished)return;this.finished=!0;let{state:e,suffix:t,pos:n,blockLen:r}=this;e[n]^=t,t&128&&n===r-1&&this.keccak(),e[r-1]^=128,this.keccak()}writeInto(e){l(this,!1),n(e),this.finish();let t=this.state,{blockLen:r}=this;for(let n=0,i=e.length;n<i;){this.posOut>=r&&this.keccak();let a=Math.min(r-this.posOut,i-n);e.set(t.subarray(this.posOut,this.posOut+a),n),this.posOut+=a,n+=a}return e}xofInto(e){if(!this.enableXOF)throw Error(`XOF is not possible for this instance`);return this.writeInto(e)}xof(t){return e(t),this.xofInto(new Uint8Array(t))}digestInto(e){if(c(e,this),this.finished)throw Error(`digest() was already called`);return this.writeInto(e),this.destroy(),e}digest(){return this.digestInto(new Uint8Array(this.outputLen))}destroy(){this.destroyed=!0,this.state.fill(0)}_cloneInto(e){let{blockLen:t,suffix:n,outputLen:r,rounds:i,enableXOF:o}=this;return e||=new a(t,n,r,o,i),e.state32.set(this.state32),e.pos=this.pos,e.posOut=this.posOut,e.finished=this.finished,e.rounds=i,e.suffix=n,e.outputLen=r,e.enableXOF=o,e.destroyed=this.destroyed,e}},E=((e,t,n)=>u(()=>new fe(t,e,n)))(1,136,32);function D(e){let t=``;for(let n of e)t+=n.toString(16).padStart(2,`0`);return t}var pe=O(`workerHash()`),me=O(`workerResolvers()`);function O(e){return`0x`+D(E(new TextEncoder().encode(e))).slice(0,8)}function he(e){let t=e.startsWith(`0x`)?e.slice(2):e,n=new Uint8Array(t.length/2);for(let e=0;e<n.length;e++)n[e]=parseInt(t.slice(e*2,e*2+2),16);return n}async function ge(e,t){let n=await k(e,t,pe),r=await k(e,t,me);return{workerHash:`0x`+N(n),resolvers:F(r)}}async function k(e,t,n){let r=await e.request({method:`eth_call`,params:[{to:t,data:n},`latest`]});if(typeof r!=`string`)throw Error(`eth_call did not return data`);return he(r)}var A=67108864;async function j(e,t){let n=()=>Error(`body exceeds the ${t}-byte bundle cap`);if(!e.body){let r=new Uint8Array(await e.arrayBuffer());if(r.byteLength>t)throw n();return r}let r=e.body.getReader(),i=[],a=0;for(;;){let{value:e,done:o}=await r.read();if(o)break;if(a+=e.byteLength,a>t)throw await r.cancel().catch(()=>{}),n();i.push(e)}let o=new Uint8Array(a),s=0;for(let e of i)o.set(e,s),s+=e.byteLength;return o}async function M(e,t=A,n=[]){let r=[];for(let i of e.resolvers){let a;try{if(/^(https?|blob):/.test(i)){let e=await fetch(i);if(!e.ok)throw Error(`HTTP ${e.status}`);a=await j(e,t)}else{let e=n.find(e=>e.matches(i));if(!e){r.push(`${i}: unrecognized resolver kind (ignored)`);continue}a=await e.fetch(i,t)}}catch(e){r.push(`${i}: ${e.message}`);continue}let o=`0x`+D(E(a));if(o!==e.workerHash){r.push(`${i}: hash mismatch (got ${o}, want ${e.workerHash})`);continue}return a}throw Error(`no resolver yielded bytes matching workerHash: ${r.join(`; `)}`)}function N(e){if(e.length<32)throw Error(`short bytes32 return`);return D(e.slice(0,32))}function P(e,t){if(t<0||t+32>e.length)throw Error(`ABI decode: word out of bounds`);let n=0;for(let r=t;r<t+32;r++)if(n=n*256+e[r],n>2**53-1)throw Error(`ABI decode: word too large`);return n}function F(e){let t=P(e,0),n=P(e,t);if(t+32+n*32>e.length)throw Error(`ABI decode: array length out of bounds`);let r=[],i=new TextDecoder;for(let a=0;a<n;a++){let n=t+32+P(e,t+32+a*32),o=P(e,n);if(n+32+o>e.length)throw Error(`ABI decode: string out of bounds`);r.push(i.decode(e.slice(n+32,n+32+o)))}return r}function I(e,t=`value`){return L(e,t,new Set)}function L(e,t,n){switch(typeof e){case`undefined`:case`boolean`:case`number`:case`string`:return e;case`object`:break;default:throw z(t,typeof e)}if(e===null)return null;if(e instanceof Uint8Array){if(R(e.buffer))throw z(t,`a Uint8Array over a detached buffer`);return new Uint8Array(e)}if(e instanceof ArrayBuffer){if(R(e))throw z(t,`a detached ArrayBuffer`);return e.slice(0)}if(n.has(e))throw z(t,`a value that contains itself`);n.add(e);try{if(Array.isArray(e)){let r=Array(e.length);for(let i=0;i<e.length;i++)r[i]=L(e[i],`${t}[${i}]`,n);return r}let r=Object.getPrototypeOf(e);if(r!==Object.prototype&&r!==null)throw z(t,_e(e));let i={};for(let r of Object.keys(e))Object.defineProperty(i,r,{value:L(e[r],`${t}.${r}`,n),writable:!0,enumerable:!0,configurable:!0});return i}finally{n.delete(e)}}function R(e){return e.detached===!0}function _e(e){let t=e.constructor?.name;return typeof t==`string`&&t?`a ${t}`:`an object with a non-plain prototype`}function z(e,t){return TypeError(`${e} is not a plain value (\xA79.4): got ${t}`)}var ve=new Set([`method`,`headers`,`body`,`redirect`,`signal`]);function ye(e){if(!e)return;let t;for(let n of Object.keys(e))ve.has(n)||(t??={},Object.defineProperty(t,n,{value:I(e[n],`init.${n}`),writable:!0,enumerable:!0,configurable:!0}));return t}var B=class extends Error{code;constructor(e){super(e.message),this.name=e.name,this.code=e.code}};function be(e){if(e instanceof Error){let t=e.code;return{name:e.name,message:e.message,...typeof t==`string`?{code:t}:{}}}return{name:`Error`,message:String(e)}}var xe=class{#e;#t=1;#n=new Map;#r=new Map;#i=new Map;#a=new Map;constructor(e){this.#e=e,e.onmessage=e=>this.#s(e.data),e.start?.()}on(e,t){this.#r.set(e,t)}onEvent(e,t){this.#i.set(e,t)}emit(e,t,n){this.#o({t:`evt`,topic:e,data:t},n)}call(e,t,n){let r=this.#t++;return new Promise((i,a)=>{let o;if(n?.signal){let e=n.signal;if(e.aborted){a(V());return}let t=()=>{this.#n.delete(r)&&(this.#o({t:`abort`,id:r}),a(V()))};e.addEventListener(`abort`,t),o=()=>e.removeEventListener(`abort`,t)}this.#n.set(r,{resolve:i,reject:a,cleanup:o}),this.#o({t:`req`,id:r,method:e,args:t},n?.transfer)})}#o(e,t){this.#e.postMessage(e,t??[])}async#s(e){switch(e.t){case`evt`:this.#i.get(e.topic)?.(e.data);return;case`abort`:this.#a.get(e.id)?.abort(V());return;case`res`:{let t=this.#n.get(e.id);if(!t)return;this.#n.delete(e.id),t.cleanup?.(),e.ok?t.resolve(e.value):t.reject(new B(e.error));return}case`req`:{let t=this.#r.get(e.method);if(!t){this.#o({t:`res`,id:e.id,ok:!1,error:{name:`Error`,message:`no handler: ${e.method}`}});return}let n=new AbortController;this.#a.set(e.id,n);try{let r=await t(e.args,{signal:n.signal});this.#o({t:`res`,id:e.id,ok:!0,value:r.value},r.transfer)}catch(t){this.#o({t:`res`,id:e.id,ok:!1,error:be(t)})}finally{this.#a.delete(e.id)}return}}}};function V(){return new DOMException(`The operation was aborted.`,`AbortError`)}function Se(e){let t=new Map,n=new Map,r=1,i=t=>{let i=r++;return n.set(i,t),t.closed.then(t=>{n.delete(i),e.emit(`stream.closed`,{streamId:i,info:t})}),{value:{streamId:i,readable:t.readable,writable:t.writable},transfer:[t.readable,t.writable]}},a=e=>{let n=t.get(e);if(!n)throw Error(`unknown connId ${e}`);return n},o=e=>{let t=n.get(e);if(!t)throw Error(`unknown streamId ${e}`);return t};return e.on(`kps.dial`,async({addr:n},{signal:i})=>{let a=await f(n,{signal:i}),o=r++;return t.set(o,a),a.closed.then(n=>{t.delete(o),e.emit(`conn.closed`,{connId:o,info:n})}),{value:{connId:o,remoteAddress:a.remoteAddress}}}),e.on(`kps.openStream`,async({addr:e},{signal:t})=>{let n=await p(e,{signal:t});return i(n)}),e.on(`conn.openStream`,async({connId:e},{signal:t})=>i(await a(e).openStream({signal:t}))),e.on(`conn.acceptStream`,async({connId:e},{signal:t})=>i(await a(e).acceptStream({signal:t}))),e.on(`conn.close`,async({connId:e,reason:n})=>(await a(e).close(n),t.delete(e),{value:void 0})),e.on(`conn.sendDatagram`,async({connId:e,data:t},{signal:n})=>(await a(e).sendDatagram(t,{signal:n}),{value:void 0})),e.on(`conn.receiveDatagram`,async({connId:e},{signal:t})=>({value:await a(e).receiveDatagram({signal:t})})),e.on(`stream.closeWrite`,async({streamId:e})=>(await o(e).closeWrite(),{value:void 0})),e.on(`stream.cancelRead`,async({streamId:e,reason:t})=>(await o(e).cancelRead(t),{value:void 0})),e.on(`stream.resetWrite`,async({streamId:e,reason:t})=>(await o(e).resetWrite(t),{value:void 0})),e.on(`stream.close`,async({streamId:e,reason:t})=>(await o(e).close(t),n.delete(e),{value:void 0})),()=>{for(let e of n.values())e.close({code:`closed`}).catch(()=>{});for(let e of t.values())e.close({code:`closed`});n.clear(),t.clear()}}async function Ce(e,t){let n=ye(t);if(e instanceof Request){let r=t?.body instanceof ReadableStream,i=t?new Request(e,{...r?{duplex:`half`}:{},...t}):e,a=[];i.headers.forEach((e,t)=>a.push([t,e]));let o={method:i.method,headers:a,redirect:i.redirect,hasSignal:!0};n&&(o.forwarded=n);let s=[];return i.body&&(o.body=i.body,s.push(i.body)),{url:i.url,requestInit:o,transfer:s,signal:i.signal}}let r=typeof e==`string`?e:e.href;if(!t)return{url:r};let i=t,a=[],o,s;if(i.body!=null){if(i.body instanceof ReadableStream)o=i.body,a.push(i.body);else if(typeof i.body==`string`)o=new TextEncoder().encode(i.body),a.push(o.buffer);else if(i.body instanceof Uint8Array||i.body instanceof ArrayBuffer)o=i.body instanceof Uint8Array?i.body:new Uint8Array(i.body);else{let e=new Response(i.body);o=new Uint8Array(await e.arrayBuffer()),s=e.headers.get(`content-type`)??void 0,a.push(o.buffer)}}let c={};i.method&&(c.method=i.method);let l=we(i.headers)??[];return s&&!l.some(([e])=>e.toLowerCase()===`content-type`)&&l.push([`content-type`,s]),l.length&&(c.headers=l),o!==void 0&&(c.body=o),i.redirect&&(c.redirect=i.redirect),i.signal&&(c.hasSignal=!0),n&&(c.forwarded=n),{url:r,requestInit:c,transfer:a,signal:i.signal??void 0}}function we(e){if(!e)return;let t=[];if(e instanceof Headers)e.forEach((e,n)=>t.push([n,e]));else if(Array.isArray(e))for(let[n,r]of e)t.push([n,r]);else for(let[n,r]of Object.entries(e))t.push([n,String(r)]);return t}var Te=`anon-rpc-harness`,H=`kv`;function Ee(){return typeof indexedDB>`u`?Promise.resolve(new Oe):De.open()}function U(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}var De=class e{#e;constructor(e){this.#e=e}static async open(){let t=indexedDB.open(Te,1);return t.onupgradeneeded=()=>{t.result.createObjectStore(H)},new e(await U(t))}#t(e){return this.#e.transaction(H,e).objectStore(H)}async get(e,t){return await U(this.#t(`readonly`).get([e,t]))}async set(e,t,n){await U(this.#t(`readwrite`).put(n,[e,t]))}async delete(e,t){await U(this.#t(`readwrite`).delete([e,t]))}async has(e,t){return await U(this.#t(`readonly`).getKey([e,t]))!==void 0}async listKeys(e,t=``){let n=[];return await this.#n(`readonly`,e,t,e=>{n.push(e.key[1])}),n}async clear(e,t=``){await this.#n(`readwrite`,e,t,e=>{e.delete()})}#n(e,t,n,r){return new Promise((i,a)=>{let o=this.#t(e),s=IDBKeyRange.lowerBound([t,n]),c=e===`readwrite`?o.openCursor(s):o.openKeyCursor(s);c.onsuccess=()=>{let e=c.result;if(!e)return i();let[a,o]=e.key;if(a!==t||!o.startsWith(n))return i();r(e),e.continue()},c.onerror=()=>a(c.error)})}},Oe=class{#e=new Map;#t(e){let t=this.#e.get(e);return t||this.#e.set(e,t=new Map),t}async get(e,t){return this.#t(e).get(t)}async set(e,t,n){this.#t(e).set(t,n)}async delete(e,t){this.#t(e).delete(t)}async has(e,t){return this.#t(e).has(t)}async listKeys(e,t=``){return[...this.#t(e).keys()].filter(e=>e.startsWith(t))}async clear(e,t=``){let n=this.#t(e);if(!t)return n.clear();for(let e of[...n.keys()])e.startsWith(t)&&n.delete(e)}},ke=new TextEncoder,W=`\r
`;function Ae(e){if(!e.startsWith(`kps:`))return;let t=e.slice(4),n=t.indexOf(`/`);if(n<=0)throw Error(`malformed kps resolver: missing /path`);let r=t.slice(0,n),i=t.slice(n);if(r.split(`:`).length<3)throw Error(`malformed kps resolver: bad address`);return{addr:r,path:i}}function je(e,t,n=[]){let r=n.length?`Accept-Encoding: ${n.join(`, `)}${W}`:``;return ke.encode(`GET ${e} HTTP/1.1${W}Host: ${t}${W}${r}${W}`)}var G=[[`zstd`,[`zstd`]],[`br`,[`br`,`brotli`]],[`gzip`,[`gzip`]],[`deflate`,[`deflate`]]];function K(){return globalThis.DecompressionStream}function q(e){let t=K();if(t)for(let n of G.find(([t])=>t===e)?.[1]??[])try{return new t(n),n}catch{}}function Me(){return G.map(([e])=>e).filter(e=>q(e)!==void 0)}async function Ne(e,t,n){let r=K(),i=q(e);if(!r||i===void 0)throw Error(`undecodable Content-Encoding: ${e}`);let a=new Blob([t]).stream().pipeThrough(new r(i)).getReader(),o=[],s=0;for(;;){let{value:e,done:t}=await a.read();if(t)break;if(s+=e.byteLength,s>n)throw await a.cancel().catch(()=>{}),Error(`decoded body exceeds the ${n}-byte bundle cap`);o.push(e)}let c=new Uint8Array(s),l=0;for(let e of o)c.set(e,l),l+=e.byteLength;return c}function Pe(e){let t=Fe(e);if(t<0)throw Error(`no header terminator in response`);let n=new TextDecoder(`utf-8`,{fatal:!1}).decode(e.subarray(0,t)).split(W),r=/^HTTP\/1\.1 (\d{3})(?: |$)/.exec(n[0]);if(!r)throw Error(`malformed status line: ${JSON.stringify(n[0].slice(0,80))}`);let i=Number(r[1]),a=[];for(let e of n.slice(1)){if(e===``)continue;let t=e.indexOf(`:`);if(t<=0)throw Error(`malformed header line: ${JSON.stringify(e.slice(0,80))}`);let n=e.slice(0,t).trim().toLowerCase(),r=e.slice(t+1).trim();if(n===`transfer-encoding`)throw Error(`forbidden Transfer-Encoding in response`);a.push([n,r])}return{status:i,headers:a,body:e.subarray(t+4)}}function Fe(e){for(let t=0;t+3<e.length;t++)if(e[t]===13&&e[t+1]===10&&e[t+2]===13&&e[t+3]===10)return t;return-1}async function Ie(e,t,n){let{openStream:r}=await d(async()=>{let{openStream:e}=await import(`./dist-CWBTRk4s.js`);return{openStream:e}},__vite__mapDeps([0,1]),import.meta.url),i=await r(e);try{let r=e.slice(e.lastIndexOf(`:`)+1),a=Me(),o=i.writable.getWriter();await o.write(je(t,r,a)),await o.close();let s=i.readable.getReader(),c=[],l=0;for(;;){let{value:e,done:t}=await s.read();if(t)break;if(l+=e.byteLength,l>n+65536)throw await s.cancel().catch(()=>{}),Error(`response exceeds the ${n}-byte bundle cap`);c.push(e)}let u=new Uint8Array(l),d=0;for(let e of c)u.set(e,d),d+=e.byteLength;let f=Pe(u);if(f.status!==200)throw Error(`HTTP ${f.status}`);let p=f.headers.find(([e])=>e===`content-encoding`)?.[1].toLowerCase();if(p&&p!==`identity`){if(!a.includes(p))throw Error(`unadvertised Content-Encoding: ${p}`);return Ne(p,f.body,n)}if(f.body.byteLength>n)throw Error(`body exceeds the ${n}-byte bundle cap`);return f.body}finally{await i.close().catch(()=>{})}}var Le={matches:e=>e.startsWith(`kps:`),fetch:(e,t)=>{let{addr:n,path:r}=Ae(e);return Ie(n,r,t)}},Re=1e3,ze=class{ready;fetch;#e;#t;#n;#r;#i;#a;#o=new ee;#s=new te(Re);#c=!1;#l=new Map;#u=1;#d;#f;#p;#m;constructor(e){this.#e=e,this.#t=I(e.config,`config`),this.ready=new Promise((e,t)=>{this.#d=e,this.#f=t}),this.ready.catch(()=>{}),this.fetch=this.#v.bind(this),this.#g().catch(e=>this.#h(e))}#h(e){if(this.#p===void 0){this.#p=e,this.#f(e);for(let t of this.#l.values())t.cleanup?.(),t.reject(e);this.#l.clear(),this.#o.rejectAll(e),this.#s.close(e)}}async#g(){let e=this.#e.preExisting?.rpcProvider;if(!e)throw Error(`preExisting.rpcProvider is required to read the specifier`);let t=await M(await ge(e,this.#e.address),A,[Le]),n=new MessageChannel,r=new xe(n.port1);this.#n=r,this.#_(r);let i=document.createElement(`iframe`);i.setAttribute(`sandbox`,`allow-scripts`),i.style.display=`none`,this.#e.iframeUrl?i.src=J(this.#e.iframeUrl):i.srcdoc=`<!doctype html><meta charset="utf-8"><script>"use strict";
(() => {
  // src/iframe/iframe-boot.ts
  (() => {
    parent.postMessage({ kind: "iframe-ready" }, "*");
    const onInit = (ev) => {
      if (ev.source !== parent || ev.data?.kind !== "init") return;
      removeEventListener("message", onInit);
      const port = ev.ports[0];
      const runtimeSource = ev.data.runtimeSource;
      const bundleBytes = ev.data.bundleBytes;
      const blob = new Blob([runtimeSource], { type: "text/javascript" });
      const worker = new Worker(URL.createObjectURL(blob));
      worker.postMessage({ kind: "init", port, bundleBytes, config: ev.data.config }, [port]);
      worker.addEventListener("error", (e) => {
        parent.postMessage({ kind: "worker-error", message: e.message }, "*");
      });
    };
    addEventListener("message", onInit);
  })();
})();
<\/script>`,this.#r=i;let a=new Promise(e=>{let t=t=>{t.source===i.contentWindow&&(t.data?.kind===`iframe-ready`&&e(),t.data?.kind===`worker-error`&&this.#h(Error(`worker error: ${t.data.message}`)))};this.#a=t,window.addEventListener(`message`,t)});document.body.appendChild(i),await a,i.contentWindow.postMessage({kind:`init`,runtimeSource:`"use strict";
(() => {
  // ../harness-core/dist/errors.js
  var RpcError = class extends Error {
    code;
    constructor(e) {
      super(e.message);
      this.name = e.name;
      this.code = e.code;
    }
  };
  function serializeError(err) {
    if (err instanceof Error) {
      const code = err.code;
      return {
        name: err.name,
        message: err.message,
        ...typeof code === "string" ? { code } : {}
      };
    }
    return { name: "Error", message: String(err) };
  }

  // src/protocol.ts
  var PortRpc = class {
    #port;
    #nextId = 1;
    #pending = /* @__PURE__ */ new Map();
    #handlers = /* @__PURE__ */ new Map();
    #events = /* @__PURE__ */ new Map();
    // AbortControllers for in-flight inbound requests, keyed by caller-side id.
    #inbound = /* @__PURE__ */ new Map();
    constructor(port) {
      this.#port = port;
      port.onmessage = (ev) => this.#onMessage(ev.data);
      port.start?.();
    }
    /** Register a handler for an inbound method. */
    on(method, handler) {
      this.#handlers.set(method, handler);
    }
    /** Register a handler for an inbound fire-and-forget event. */
    onEvent(topic, handler) {
      this.#events.set(topic, handler);
    }
    /** Fire-and-forget event to the peer. */
    emit(topic, data, transfer) {
      this.#post({ t: "evt", topic, data }, transfer);
    }
    /** Call a remote method and await its result. */
    call(method, args, opts) {
      const id = this.#nextId++;
      return new Promise((resolve, reject) => {
        let cleanup;
        if (opts?.signal) {
          const signal = opts.signal;
          if (signal.aborted) {
            reject(abortError());
            return;
          }
          const onAbort = () => {
            if (!this.#pending.delete(id)) return;
            this.#post({ t: "abort", id });
            reject(abortError());
          };
          signal.addEventListener("abort", onAbort);
          cleanup = () => signal.removeEventListener("abort", onAbort);
        }
        this.#pending.set(id, {
          resolve,
          reject,
          cleanup
        });
        this.#post({ t: "req", id, method, args }, opts?.transfer);
      });
    }
    #post(msg, transfer) {
      this.#port.postMessage(msg, transfer ?? []);
    }
    async #onMessage(msg) {
      switch (msg.t) {
        case "evt": {
          this.#events.get(msg.topic)?.(msg.data);
          return;
        }
        case "abort": {
          this.#inbound.get(msg.id)?.abort(abortError());
          return;
        }
        case "res": {
          const p = this.#pending.get(msg.id);
          if (!p) return;
          this.#pending.delete(msg.id);
          p.cleanup?.();
          if (msg.ok) p.resolve(msg.value);
          else p.reject(new RpcError(msg.error));
          return;
        }
        case "req": {
          const handler = this.#handlers.get(msg.method);
          if (!handler) {
            this.#post({
              t: "res",
              id: msg.id,
              ok: false,
              error: { name: "Error", message: \`no handler: \${msg.method}\` }
            });
            return;
          }
          const ac = new AbortController();
          this.#inbound.set(msg.id, ac);
          try {
            const result = await handler(msg.args, { signal: ac.signal });
            this.#post(
              { t: "res", id: msg.id, ok: true, value: result.value },
              result.transfer
            );
          } catch (err) {
            this.#post({
              t: "res",
              id: msg.id,
              ok: false,
              error: serializeError(err)
            });
          } finally {
            this.#inbound.delete(msg.id);
          }
          return;
        }
      }
    }
  };
  function abortError() {
    return new DOMException("The operation was aborted.", "AbortError");
  }

  // src/worker/anon-rpc-worker-api.ts
  function makeWorkerApi(rpc, config) {
    const callAborts = /* @__PURE__ */ new Map();
    const preAborted = /* @__PURE__ */ new Set();
    rpc.onEvent("call-abort", ({ callId }) => {
      const ac = callAborts.get(callId);
      if (ac) ac.abort(new DOMException("aborted", "AbortError"));
      else preAborted.add(callId);
    });
    const streamClosed = /* @__PURE__ */ new Map();
    const connClosed = /* @__PURE__ */ new Map();
    rpc.onEvent("stream.closed", ({ streamId, info }) => {
      streamClosed.get(streamId)?.(info);
      streamClosed.delete(streamId);
    });
    rpc.onEvent("conn.closed", ({ connId, info }) => {
      connClosed.get(connId)?.(info);
      connClosed.delete(connId);
    });
    function makeStream(p) {
      const closed = new Promise((resolve) => streamClosed.set(p.streamId, resolve));
      return {
        readable: p.readable,
        writable: p.writable,
        closeWrite: () => rpc.call("stream.closeWrite", { streamId: p.streamId }),
        cancelRead: (reason) => rpc.call("stream.cancelRead", { streamId: p.streamId, reason }),
        resetWrite: (reason) => rpc.call("stream.resetWrite", { streamId: p.streamId, reason }),
        close: (reason) => rpc.call("stream.close", { streamId: p.streamId, reason }),
        closed
      };
    }
    function makeConn(connId, remoteAddress) {
      const closed = new Promise((resolve) => connClosed.set(connId, resolve));
      return {
        remoteAddress,
        openStream: async (opts) => makeStream(await rpc.call("conn.openStream", { connId }, sigOpt(opts))),
        acceptStream: async (opts) => makeStream(await rpc.call("conn.acceptStream", { connId }, sigOpt(opts))),
        close: (reason) => rpc.call("conn.close", { connId, reason }),
        sendDatagram: (data, opts) => rpc.call("conn.sendDatagram", { connId, data }, sigOpt(opts)),
        receiveDatagram: (opts) => rpc.call("conn.receiveDatagram", { connId }, sigOpt(opts)),
        closed
      };
    }
    const kps = {
      dial: async (addr, opts) => {
        const { connId, remoteAddress } = await rpc.call("kps.dial", { addr }, sigOpt(opts));
        return makeConn(connId, remoteAddress);
      },
      openStream: async (addr, opts) => makeStream(await rpc.call("kps.openStream", { addr }, sigOpt(opts)))
    };
    const storage = {
      get: (key, opts) => rpc.call("storage.get", { key }, sigOpt(opts)),
      set: (key, value, opts) => rpc.call("storage.set", { key, value }, sigOpt(opts)),
      delete: (key, opts) => rpc.call("storage.delete", { key }, sigOpt(opts)),
      has: (key, opts) => rpc.call("storage.has", { key }, sigOpt(opts)),
      clear: (opts) => rpc.call("storage.clear", { prefix: opts?.prefix }, sigOpt(opts)),
      list: (opts) => listKeys(rpc, opts?.prefix, opts?.signal)
    };
    const log = {
      debug: (...args) => rpc.emit("log", { level: "debug", args }),
      info: (...args) => rpc.emit("log", { level: "info", args }),
      warn: (...args) => rpc.emit("log", { level: "warn", args }),
      error: (...args) => rpc.emit("log", { level: "error", args })
    };
    function acceptCall(opts) {
      const abortErr = () => new DOMException("aborted", "AbortError");
      const signal = opts?.signal;
      const toCall = (r) => makeFetchCall(rpc, callAborts, preAborted, r.callId, r.url, r.requestInit);
      if (signal?.aborted) return Promise.reject(signal.reason ?? abortErr());
      const pending = rpc.call("acceptCall", {});
      if (!signal) return pending.then(toCall);
      return new Promise((resolve, reject) => {
        let settled = false;
        const onAbort = () => {
          if (settled) return;
          settled = true;
          pending.then((r) => rpc.emit("requeue-call", { callId: r.callId }), () => {
          });
          reject(signal.reason ?? abortErr());
        };
        signal.addEventListener("abort", onAbort, { once: true });
        pending.then(
          (r) => {
            if (settled) return;
            settled = true;
            signal.removeEventListener("abort", onAbort);
            resolve(toCall(r));
          },
          (e) => {
            if (settled) return;
            settled = true;
            signal.removeEventListener("abort", onAbort);
            reject(e);
          }
        );
      });
    }
    return {
      signalReady: () => rpc.emit("ready", {}),
      // Failure finality (§7: later signals ignored) is enforced host-side —
      // #fail is one-shot and resolving an already-rejected ready is a no-op.
      signalFailed: (reason) => rpc.emit("failed", { reason }),
      acceptCall,
      config,
      kps,
      storage,
      log
    };
  }
  function makeFetchCall(rpc, callAborts, preAborted, callId, url, wireInit) {
    let requestInit;
    if (wireInit) {
      const { hasSignal, forwarded, ...rest } = wireInit;
      requestInit = { ...forwarded, ...rest };
      if (hasSignal) {
        const ac = new AbortController();
        callAborts.set(callId, ac);
        requestInit = { ...requestInit, signal: ac.signal };
        if (preAborted.delete(callId)) ac.abort(new DOMException("aborted", "AbortError"));
      }
    }
    let responded = false;
    return {
      kind: "fetch",
      url,
      ...requestInit ? { requestInit } : {},
      respond(response) {
        if (responded) throw new Error("respond() called more than once");
        responded = true;
        Promise.resolve(response).then((r) => {
          const transfer = r.body instanceof ReadableStream ? [r.body] : r.body instanceof Uint8Array ? [r.body.buffer] : [];
          return rpc.call("respond", { callId, ok: true, response: r }, { transfer });
        }).catch(
          (e) => (
            // Carry name/code across the boundary (§12): host logic may branch
            // on code, never on message text.
            rpc.call("respond", { callId, ok: false, error: serializeError(e) })
          )
        ).catch(() => {
        }).finally(() => callAborts.delete(callId));
      }
    };
  }
  async function* listKeys(rpc, prefix, signal) {
    const keys = await rpc.call("storage.list", { prefix }, signal ? { signal } : void 0);
    for (const k of keys) yield k;
  }
  function sigOpt(opts) {
    return opts?.signal ? { signal: opts.signal } : void 0;
  }

  // src/worker/worker-runtime.ts
  var importScripts = (url) => (
    // eslint-disable-next-line no-restricted-globals
    self.importScripts(url)
  );
  function bundleScriptUrl(bundle) {
    const probeUrl = URL.createObjectURL(new Blob([";"], { type: "text/javascript" }));
    try {
      importScripts(probeUrl);
      return URL.createObjectURL(bundle);
    } catch {
      return new FileReaderSync().readAsDataURL(bundle);
    } finally {
      URL.revokeObjectURL(probeUrl);
    }
  }
  addEventListener("message", function onInit(ev) {
    if (ev.data?.kind !== "init") return;
    removeEventListener("message", onInit);
    const port = ev.data.port;
    const bundleBytes = ev.data.bundleBytes;
    const config = ev.data.config;
    const rpc = new PortRpc(port);
    const api = makeWorkerApi(rpc, config);
    globalThis.anonRpcWorker = api;
    try {
      const blob = new Blob([bundleBytes], { type: "text/javascript" });
      importScripts(bundleScriptUrl(blob));
    } catch (err) {
      const message = err?.message ?? String(err);
      api.log.error("worker bundle failed to load:", message);
      rpc.emit("boot-error", { message });
    }
  });
})();
`,bundleBytes:t,config:this.#t},`*`,[n.port2])}#_(e){this.#i=Se(e),e.onEvent(`ready`,()=>this.#d()),e.onEvent(`boot-error`,({message:e})=>{this.#h(Error(`worker bundle failed to load: ${e}`))}),e.onEvent(`failed`,({reason:e})=>{this.#h(new B({name:`WorkerFailedError`,message:e?.message??`worker signalled failure`,code:e?.code}))}),e.onEvent(`requeue-call`,({callId:e})=>{let t=this.#l.get(e);t&&this.#o.pushFront(t)}),e.onEvent(`log`,({level:e,args:t})=>{this.#s.push({level:e,args:t}),!this.#c&&(console[e]??console.log).call(console,`[worker]`,...t.map(Be))}),e.on(`acceptCall`,async(e,{signal:t})=>{let n=await this.#o.take(t);return{value:{callId:n.callId,url:n.url,requestInit:n.requestInit},transfer:n.bodyTransfer??[]}}),e.on(`respond`,async e=>{let t=this.#l.get(e.callId);if(!t)return{value:void 0};if(this.#l.delete(e.callId),t.cleanup?.(),e.ok&&e.response)try{t.resolve(Ve(e.response))}catch(e){t.reject(e)}else t.reject(new B(e.error??{name:`Error`,message:`worker failed the call`}));return{value:void 0}});let t=this.#e.address.toLowerCase(),n=()=>this.#m??=Ee();e.on(`storage.get`,async({key:e})=>({value:await(await n()).get(t,e)})),e.on(`storage.set`,async({key:e,value:r})=>(await(await n()).set(t,e,r),{value:void 0})),e.on(`storage.delete`,async({key:e})=>(await(await n()).delete(t,e),{value:void 0})),e.on(`storage.has`,async({key:e})=>({value:await(await n()).has(t,e)})),e.on(`storage.list`,async({prefix:e})=>({value:await(await n()).listKeys(t,e)})),e.on(`storage.clear`,async({prefix:e})=>(await(await n()).clear(t,e),{value:void 0}))}async#v(e,t){if(this.#p!==void 0)throw this.#p;let{url:n,requestInit:r,transfer:i,signal:a}=await Ce(e,t),o=this.#u++;return new Promise((e,t)=>{let s={callId:o,url:n,requestInit:r,bodyTransfer:i,resolve:e,reject:t};if(this.#l.set(o,s),a){let e=()=>{this.#o.remove(s)||this.#n?.emit(`call-abort`,{callId:o}),this.#l.delete(o)&&t(a.reason??new DOMException(`aborted`,`AbortError`))};if(a.aborted){this.#l.delete(o),t(a.reason??new DOMException(`aborted`,`AbortError`));return}a.addEventListener(`abort`,e,{once:!0}),s.cleanup=()=>a.removeEventListener(`abort`,e)}this.#o.push(s)})}acceptLog(e){return this.#c=!0,this.#s.take(e?.signal)}close(){this.#i?.(),this.#a&&window.removeEventListener(`message`,this.#a),this.#r?.remove(),this.#h(Error(`worker closed`))}};function J(e){let t;try{t=new URL(e,location.href)}catch{throw Error(`iframeUrl is not a valid URL: ${e}`)}if(t.origin!==location.origin)throw Error(`iframeUrl must be same-origin with the host (${location.origin}), got ${t.origin} \u2014 a cross-origin bootstrap would control the isolation boundary (\xA76)`);return t.href}function Be(e){return e instanceof Uint8Array?`<${e.byteLength} bytes>`:e}function Ve(e){let t=new Headers;for(let[n,r]of e.headers)t.append(n,r);let n=e.status,r=n===204||n===205||n===304?null:e.body,i=new Response(r,{status:n,headers:t});return e.url&&Object.defineProperty(i,"url",{value:e.url}),i}var Y=`https://ethereum-rpc.publicnode.com`,X=[{id:`nox`,label:`Nox mixnet`,specifier:`0x35133267A8F7EC35046a83DCA0f4Ca8A6e1b7A9A`,specifierRpc:`https://ethereum-sepolia-rpc.publicnode.com`},{id:`tor`,label:`Tor`,specifier:`0x700dA3193D35fA54Cd3fBf29B66f2a2A0385659e`,specifierRpc:Y,config:{gateways:[`152.236.3.22:12298:uEiCH0VdbhryzJcMtCfB0vLA4sOvHdQ4hq5w7CopcwU59bQ`]}},{id:`nym`,label:`Nym mixnet`,specifier:`0x3aCD9742C68F6d993066Ae25533e09b9e1f60eD0`,specifierRpc:Y}],He=e=>({async request({method:t,params:n}){let r=await(await fetch(e,{method:`POST`,headers:{"content-type":`application/json`},body:JSON.stringify({jsonrpc:`2.0`,id:1,method:t,params:n??[]})})).json();if(r.error!==void 0)throw Error(r.error.message);return r.result}}),Z=new Map;function Q(e=X[0]){let t=Z.get(e.id);return t===void 0&&(t=new ze({address:e.specifier,...e.config===void 0?{}:{config:e.config},preExisting:{rpcProvider:He(e.specifierRpc)}}),Z.set(e.id,t)),t.fetch}async function Ue(e,t,n,r){let i=await(await Q(r)(e,{method:`POST`,headers:{"content-type":`application/json`},body:JSON.stringify({jsonrpc:`2.0`,id:1,method:t,params:n})})).json();if(i.error!==void 0)throw Object.assign(Error(i.error.message),{data:i.error.data});return i.result}var $=a(`opaque:anon-reads`),We=()=>{try{return localStorage.getItem($)===`on`}catch{return!1}},Ge=e=>{try{localStorage.setItem($,e?`on`:`off`)}catch{}};export{Ge as a,Ue as i,Q as n,E as o,We as r,X as t};