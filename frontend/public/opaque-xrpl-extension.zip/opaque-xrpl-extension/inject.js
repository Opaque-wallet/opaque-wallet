(function() {
	//#region frontend/src/lib/opaque-adapter.ts
	const ICON = "data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%228%22 fill=%22%23070608%22/%3E%3Cpath d=%22M16 7l9 9-9 9-9-9z%22 fill=%22none%22 stroke=%22%23ff7a18%22 stroke-width=%222%22/%3E%3C/svg%3E";
	var OpaqueAdapter = class {
		id = "opaque";
		name = "Opaque";
		icon = ICON;
		url;
		capabilities = {
			sign: true,
			signAndSubmit: true,
			signMessage: true
		};
		#walletUrl;
		#origin;
		#timeoutMs;
		#popup = null;
		#ready;
		#account = null;
		#next = 0;
		#listeners = /* @__PURE__ */ new Map();
		constructor(options = {}) {
			this.#walletUrl = options.walletUrl ?? "https://opaque-xrpl.vercel.app/testnet/xrpl-connect.html";
			this.#origin = new URL(this.#walletUrl).origin;
			this.#timeoutMs = options.timeoutMs ?? 3e5;
			this.url = this.#origin;
		}
		async isAvailable() {
			return typeof window !== "undefined" && typeof window.open === "function";
		}
		/** A stored account reconnects without a popup. */
		serializeReconnectOptions() {
			return this.#account === null ? void 0 : { account: this.#account };
		}
		async connect(options) {
			if (options?.account?.address !== void 0) this.#account = options.account;
			else this.#account = await this.#request("connect", { network: options?.network?.id ?? null });
			this.#emit("connect", this.#account);
			return this.#account;
		}
		async disconnect() {
			this.#account = null;
			this.#popup?.close();
			this.#popup = null;
			this.#emit("disconnect", null);
		}
		async getAccount() {
			return this.#account;
		}
		async getNetwork() {
			if (this.#account === null) throw new Error("Opaque is not connected");
			return this.#account.network;
		}
		sign(transaction) {
			return this.#request("sign", { transaction });
		}
		signAndSubmit(transaction) {
			return this.#request("signAndSubmit", { transaction });
		}
		signMessage(message) {
			const text = typeof message === "string" ? { message } : { hex: Array.from(message, (b) => b.toString(16).padStart(2, "0")).join("") };
			return this.#request("signMessage", text);
		}
		on(event, callback) {
			const set = this.#listeners.get(event) ?? /* @__PURE__ */ new Set();
			set.add(callback);
			this.#listeners.set(event, set);
		}
		off(event, callback) {
			this.#listeners.get(event)?.delete(callback);
		}
		#emit(event, data) {
			for (const cb of this.#listeners.get(event) ?? []) cb(data);
		}
		/** Opens the popup once, and reuses it while it stays open. */
		#open() {
			if (this.#popup !== null && !this.#popup.closed && this.#ready !== void 0) return this.#ready;
			const popup = window.open(this.#walletUrl, "opaque-wallet", "popup,width=440,height=700");
			if (popup === null) return Promise.reject(/* @__PURE__ */ new Error("the browser blocked the Opaque popup; allow popups for this site"));
			this.#popup = popup;
			this.#ready = new Promise((resolve, reject) => {
				const timer = setTimeout(() => {
					window.removeEventListener("message", onReady);
					reject(/* @__PURE__ */ new Error("the Opaque wallet did not open"));
				}, 6e4);
				const onReady = (event) => {
					if (event.source !== popup || event.origin !== this.#origin || event.data?.type !== "opaque:ready") return;
					clearTimeout(timer);
					window.removeEventListener("message", onReady);
					resolve();
				};
				window.addEventListener("message", onReady);
			});
			return this.#ready;
		}
		async #request(method, params) {
			await this.#open();
			const popup = this.#popup;
			const id = `${Date.now()}-${this.#next++}`;
			return new Promise((resolve, reject) => {
				const done = () => {
					clearTimeout(timer);
					clearInterval(closed);
					window.removeEventListener("message", onMessage);
				};
				const timer = setTimeout(() => {
					done();
					reject(/* @__PURE__ */ new Error(`Opaque: ${method} timed out`));
				}, this.#timeoutMs);
				const closed = setInterval(() => {
					if (popup.closed) {
						done();
						reject(/* @__PURE__ */ new Error("the Opaque window was closed"));
					}
				}, 500);
				const onMessage = (event) => {
					const data = event.data;
					if (event.source !== popup || event.origin !== this.#origin || data?.type !== "opaque:response" || data.id !== id) return;
					done();
					if (data.error !== void 0) reject(new Error(data.error));
					else resolve(data.result);
				};
				window.addEventListener("message", onMessage);
				popup.postMessage({
					type: "opaque:request",
					id,
					method,
					params
				}, this.#origin);
			});
		}
	};
	//#endregion
	//#region extension-xrpl/inject.ts
	const WSS = "wss://s.altnet.rippletest.net:51233";
	const HOSTED = "https://opaque-xrpl.vercel.app/testnet/xrpl-connect.html";
	const walletUrl = () => {
		const named = document.documentElement.dataset["opaqueWallet"] ?? "";
		return /^chrome-extension:\/\/[a-p]{32}\/xrpl-connect\.html$/.test(named) ? named : HOSTED;
	};
	let opened;
	/** Made on first use: by then bridge.js has run, whichever script the browser started first. */
	const adapter = () => opened ??= new OpaqueAdapter({ walletUrl: walletUrl() });
	const SAVED = () => `opaque-extension:account:${new URL(walletUrl()).origin}`;
	let account;
	const saved = () => {
		try {
			return JSON.parse(localStorage.getItem(SAVED()) ?? "null");
		} catch {
			return null;
		}
	};
	function connected() {
		account ??= (async () => {
			const known = saved();
			const a = known !== null ? await adapter().connect({ account: known }) : await adapter().connect({ network: { id: "testnet" } });
			try {
				localStorage.setItem(SAVED(), JSON.stringify(a));
			} catch {}
			return a;
		})().catch((e) => {
			account = void 0;
			throw e;
		});
		return account;
	}
	const withAccount = async (tx) => ({
		...tx,
		Account: tx?.["Account"] ?? (await connected()).address
	});
	const rejected = (e) => /rejected in Opaque|window was closed/.test(String(e?.message));
	const hexBytes = (hex) => Uint8Array.from(hex.match(/../g) ?? [], (b) => parseInt(b, 16));
	const PAYMENT_FIELDS = {
		amount: "Amount",
		destination: "Destination",
		destinationTag: "DestinationTag",
		invoiceID: "InvoiceID",
		paths: "Paths",
		sendMax: "SendMax",
		deliverMin: "DeliverMin",
		sourceTag: "SourceTag",
		fee: "Fee"
	};
	/** sendPayment's fields as a Payment. Anything it can't carry is refused, never dropped. */
	function paymentOf(p) {
		const tx = { TransactionType: "Payment" };
		for (const [key, value] of Object.entries(p)) {
			if (value === void 0) continue;
			if (key in PAYMENT_FIELDS) tx[PAYMENT_FIELDS[key]] = value;
			else if (key === "flags" && typeof value === "number") tx["Flags"] = value;
			else if (key === "memos" && Array.isArray(value)) tx["Memos"] = value.map(({ memo }) => ({ Memo: Object.fromEntries(Object.entries({
				MemoType: memo.memoType,
				MemoData: memo.memoData,
				MemoFormat: memo.memoFormat
			}).filter(([, v]) => v !== void 0)) }));
			else throw new Error(`Opaque does not take ${key} in sendPayment; submitTransaction takes any Payment`);
		}
		return tx;
	}
	async function gem(type, p) {
		switch (type) {
			case "REQUEST_GET_NETWORK/V3": return {
				chain: "XRPL",
				network: "Testnet",
				websocket: WSS
			};
			case "REQUEST_GET_ADDRESS/V3": return { address: (await connected()).address };
			case "REQUEST_GET_PUBLIC_KEY/V3": {
				const a = await connected();
				return {
					address: a.address,
					publicKey: a.publicKey ?? ""
				};
			}
			case "REQUEST_SIGN_TRANSACTION/V3": return { signature: (await adapter().sign(await withAccount(p["transaction"]))).tx_blob };
			case "REQUEST_SUBMIT_TRANSACTION/V3": return { hash: (await adapter().signAndSubmit(await withAccount(p["transaction"]))).hash };
			case "REQUEST_SEND_PAYMENT/V3": return { hash: (await adapter().signAndSubmit(await withAccount(paymentOf(p)))).hash };
			case "REQUEST_SIGN_MESSAGE/V3": {
				const message = String(p["message"]);
				return { signedMessage: (await adapter().signMessage(p["isHex"] === true ? hexBytes(message) : message)).signature };
			}
			default: throw new Error(`Opaque does not answer ${type}; submitTransaction takes any transaction`);
		}
	}
	Object.assign(window, { gemWallet: true });
	window.addEventListener("message", (event) => {
		const d = event.data;
		if (event.source !== window || d?.source !== "GEM_WALLET_MSG_REQUEST" || typeof d.type !== "string") return;
		const reply = (body) => window.postMessage({
			source: "GEM_WALLET_MSG_RESPONSE",
			messagedId: d.messageId,
			...body
		}, location.origin);
		if (d.type === "REQUEST_IS_INSTALLED/V3") {
			reply({ isInstalled: true });
			return;
		}
		if (d.type === "REQUEST_CONNECTION") {
			reply({ isConnected: true });
			return;
		}
		gem(d.type, d.payload ?? {}).then((result) => reply({ result }), (e) => reply(rejected(e) ? {} : { error: {
			name: "Error",
			message: e.message,
			stack: ""
		} }));
	});
	const NETWORK = {
		protocol: "xrpl",
		type: "testnet",
		label: "XRPL",
		wss: WSS,
		rpc: "https://s.altnet.rippletest.net:51234"
	};
	async function crossmark(command, data) {
		const tx = data["tx"];
		switch (command) {
			case "network": return { network: NETWORK };
			case "address": return { address: (account === void 0 ? saved() : await account.catch(() => null))?.address };
			case "sign":
				if (tx?.["TransactionType"] === "SignIn") {
					const a = await connected();
					return {
						address: a.address,
						publicKey: a.publicKey ?? "",
						network: NETWORK
					};
				}
				return { txBlob: (await adapter().sign(await withAccount(tx))).tx_blob };
			case "sign-and-submit": return { resp: { result: { hash: (await adapter().signAndSubmit(await withAccount(tx))).hash } } };
			default: throw new Error(`Opaque does not answer Crossmark's ${command}`);
		}
	}
	Object.assign(window, { xrpl: Object.assign(window.xrpl ?? {}, { isCrossmark: true }) });
	window.addEventListener("message", (event) => {
		const d = event.data;
		if (event.source !== window || d?.type !== "request" || typeof d.id !== "string" || typeof d.command !== "string") return;
		const reply = (data) => window.postMessage({
			type: "response",
			request: d,
			response: {
				type: "response",
				id: d.id,
				data
			}
		}, location.origin);
		crossmark(d.command, d.data ?? {}).then(reply, (e) => reply({
			meta: rejected(e) ? { isRejected: true } : { isError: true },
			error: e.message
		}));
	});
	//#endregion
})();
